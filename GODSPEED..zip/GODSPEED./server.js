const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = 8080;
const STATIC_PATH = __dirname;

// MIME types for different file extensions
const MIME_TYPES = {
  '.html': 'text/html',
  '.css': 'text/css',
  '.js': 'text/javascript',
  '.json': 'application/json',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml'
};

// Create a simple HTTP server
const server = http.createServer((req, res) => {
  console.log(`${new Date().toISOString()} - ${req.method} ${req.url}`);
  
  // Parse the URL and get the pathname
  let url = req.url;
  
  // Handle root URL
  if (url === '/') {
    url = '/index.html';
  }
  
  // Get the file path
  const filePath = path.join(STATIC_PATH, url);
  
  // Get the file extension
  const extname = path.extname(filePath);
  
  // Default content type is plain text
  let contentType = 'text/plain';
  
  // Get content type based on file extension
  if (MIME_TYPES[extname]) {
    contentType = MIME_TYPES[extname];
  }
  
  // Read the file
  fs.readFile(filePath, (error, content) => {
    if (error) {
      if (error.code === 'ENOENT') {
        // File not found
        fs.readFile(path.join(STATIC_PATH, '404.html'), (err, content) => {
          if (err) {
            // No 404 page found
            res.writeHead(404);
            res.end('404 Not Found');
          } else {
            // 404 page found
            res.writeHead(404, { 'Content-Type': 'text/html' });
            res.end(content, 'utf-8');
          }
        });
      } else {
        // Server error
        res.writeHead(500);
        res.end(`Server Error: ${error.code}`);
      }
    } else {
      // Success
      res.writeHead(200, { 'Content-Type': contentType });
      res.end(content, 'utf-8');
    }
  });
});

// Start the server
server.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running at http://0.0.0.0:${PORT}/`);
});