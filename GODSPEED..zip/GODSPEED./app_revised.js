// DOM Elements
const header = document.getElementById('header');
const menuToggle = document.getElementById('menuToggle');
const mobileMenu = document.getElementById('mobileMenu');
const carGrid = document.getElementById('carGrid');
const categoryButtons = document.querySelectorAll('.category-btn');
const bookingForm = document.getElementById('bookingForm');
const carSelect = document.getElementById('carSelect');
const contactForm = document.getElementById('contactForm');
const newsletterForm = document.getElementById('newsletterForm');
const faqItems = document.querySelectorAll('.faq-item');
const backToTop = document.getElementById('backToTop');
const currentYearEl = document.getElementById('currentYear');

// Initialize the site
document.addEventListener('DOMContentLoaded', function() {
  // Set current year in footer
  currentYearEl.textContent = new Date().getFullYear();
  
  // Animate hero section titles
  setTimeout(function() {
    var animatedTitles = document.querySelectorAll('.animated-title');
    for (var i = 0; i < animatedTitles.length; i++) {
      (function(index) {
        setTimeout(function() {
          animatedTitles[index].style.opacity = '1';
          animatedTitles[index].style.transform = 'translateY(0)';
        }, 300 * index);
      })(i);
    }
  }, 500);
  
  // Initialize car grid
  renderCars('all');
  populateCarSelect();
  
  // Set min date for booking form
  var today = new Date().toISOString().split('T')[0];
  if (document.getElementById('pickupDate')) {
    document.getElementById('pickupDate').min = today;
  }
  if (document.getElementById('returnDate')) {
    document.getElementById('returnDate').min = today;
  }
  
  // Mobile menu toggle
  menuToggle.addEventListener('click', toggleMobileMenu);
  
  // Category filter
  for (var i = 0; i < categoryButtons.length; i++) {
    categoryButtons[i].addEventListener('click', function() {
      // Remove active class from all buttons
      for (var j = 0; j < categoryButtons.length; j++) {
        categoryButtons[j].classList.remove('active');
      }
      
      // Add active class to clicked button
      this.classList.add('active');
      
      // Filter cars
      var category = this.getAttribute('data-category');
      renderCars(category);
    });
  }
  
  // FAQ toggles
  for (var i = 0; i < faqItems.length; i++) {
    var question = faqItems[i].querySelector('.faq-question');
    question.addEventListener('click', function() {
      this.parentElement.classList.toggle('active');
    });
  }
  
  // Booking form submission
  if (bookingForm) {
    bookingForm.addEventListener('submit', handleBookingSubmit);
  }
  
  // Contact form submission
  if (contactForm) {
    contactForm.addEventListener('submit', handleContactSubmit);
  }
  
  // Newsletter form submission
  if (newsletterForm) {
    newsletterForm.addEventListener('submit', handleNewsletterSubmit);
  }
  
  // Back to top button
  window.addEventListener('scroll', handleScroll);
});

// Functions
function toggleMobileMenu() {
  mobileMenu.style.display = mobileMenu.style.display === 'block' ? 'none' : 'block';
  
  // Toggle menu icon
  var menuIcon = menuToggle.querySelector('.menu-icon');
  menuIcon.classList.toggle('active');
}

function createCarElement(id, name, description, image, categoryName, horsepower, acceleration, topSpeed, pricePerDay) {
  var carCard = document.createElement('div');
  carCard.className = 'car-card';
  
  var carHTML = '<div class="car-image">' +
    '<img src="' + image + '" alt="' + name + '">' +
    '</div>' +
    '<div class="car-details">' +
    '<div class="car-header">' +
    '<h3 class="car-name">' + name + '</h3>' +
    '<span class="car-category">' + categoryName + '</span>' +
    '</div>' +
    '<div class="car-specs">' +
    '<span class="car-spec">' +
    '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
    '<path d="M12 2v5"/>' +
    '<path d="m4.93 10.93 1.41 1.41"/>' +
    '<path d="M2 18h20"/>' +
    '<path d="M20 18a8 8 0 0 0-16 0"/>' +
    '</svg>' +
    horsepower + ' HP' +
    '</span>' +
    '<span class="car-spec">' +
    '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
    '<path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/>' +
    '</svg>' +
    acceleration +
    '</span>' +
    '<span class="car-spec">' +
    '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
    '<circle cx="12" cy="12" r="10"/>' +
    '<path d="M12 6v6l4 2"/>' +
    '</svg>' +
    topSpeed +
    '</span>' +
    '</div>' +
    '<div class="car-price">' +
    '<span>' +
    '<span class="price-amount">$' + pricePerDay + '</span>' +
    '<span class="price-period">/day</span>' +
    '</span>' +
    '<a href="#booking" class="btn btn-secondary">BOOK NOW</a>' +
    '</div>' +
    '</div>';
  
  carCard.innerHTML = carHTML;
  return carCard;
}

function renderCars(category) {
  // Clear car grid
  carGrid.innerHTML = '';
  
  // Lamborghini Aventador
  if (category === 'all' || category === 'supercars') {
    carGrid.appendChild(createCarElement(
      1,
      "Lamborghini Aventador",
      "The iconic V12 flagship Lamborghini with scissor doors and breathtaking performance.",
      "https://images.unsplash.com/photo-1544636331-e26879cd4d9b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=450",
      "SUPERCAR",
      730,
      "2.8s 0-60",
      "217 mph",
      1500
    ));
  }
  
  // Lamborghini Huracan
  if (category === 'all' || category === 'supercars') {
    carGrid.appendChild(createCarElement(
      2,
      "Lamborghini Huracan",
      "A V10-powered Italian exotic supercar with incredible performance and unmistakable styling.",
      "https://images.unsplash.com/photo-1580414057403-c5f451f30e1c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=450",
      "SUPERCAR",
      640,
      "2.9s 0-60",
      "201 mph",
      1100
    ));
  }
  
  // McLaren 720S
  if (category === 'all' || category === 'exotic') {
    carGrid.appendChild(createCarElement(
      3,
      "McLaren 720S",
      "British engineering meets supercar performance with distinctive styling and cutting-edge technology.",
      "https://images.unsplash.com/photo-1617814065893-00757125efab?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=450",
      "EXOTIC",
      710,
      "2.8s 0-60",
      "212 mph",
      1300
    ));
  }
  
  // McLaren Artura
  if (category === 'all' || category === 'exotic') {
    carGrid.appendChild(createCarElement(
      4,
      "McLaren Artura",
      "McLaren's latest hybrid supercar with plug-in technology and lightweight carbon fiber construction.",
      "https://images.unsplash.com/photo-1662555320015-158e64fbf337?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=450",
      "EXOTIC",
      671,
      "3.0s 0-60",
      "205 mph",
      1250
    ));
  }
  
  // Audi R8 V10
  if (category === 'all' || category === 'luxury') {
    carGrid.appendChild(createCarElement(
      5,
      "Audi R8 V10",
      "German precision engineering combines daily usability with supercar performance.",
      "https://images.unsplash.com/photo-1603584173870-7f23fdae1b7a?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=450",
      "LUXURY",
      562,
      "3.4s 0-60",
      "201 mph",
      900
    ));
  }
  
  // Audi RS e-tron GT
  if (category === 'all' || category === 'luxury') {
    carGrid.appendChild(createCarElement(
      6,
      "Audi RS e-tron GT",
      "Audi's all-electric performance sedan with stunning design and instant acceleration.",
      "https://images.unsplash.com/photo-1606152421802-db97b9c7a11b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=450",
      "LUXURY",
      637,
      "3.1s 0-60",
      "155 mph",
      850
    ));
  }
}

function populateCarSelect() {
  if (!carSelect) return;
  
  // Lamborghini Aventador
  var option1 = document.createElement('option');
  option1.value = "1";
  option1.textContent = "Lamborghini Aventador";
  carSelect.appendChild(option1);
  
  // Lamborghini Huracan
  var option2 = document.createElement('option');
  option2.value = "2";
  option2.textContent = "Lamborghini Huracan";
  carSelect.appendChild(option2);
  
  // McLaren 720S
  var option3 = document.createElement('option');
  option3.value = "3";
  option3.textContent = "McLaren 720S";
  carSelect.appendChild(option3);
  
  // McLaren Artura
  var option4 = document.createElement('option');
  option4.value = "4";
  option4.textContent = "McLaren Artura";
  carSelect.appendChild(option4);
  
  // Audi R8 V10
  var option5 = document.createElement('option');
  option5.value = "5";
  option5.textContent = "Audi R8 V10";
  carSelect.appendChild(option5);
  
  // Audi RS e-tron GT
  var option6 = document.createElement('option');
  option6.value = "6";
  option6.textContent = "Audi RS e-tron GT";
  carSelect.appendChild(option6);
}

function validateForm(form, errorPrefix) {
  var isValid = true;
  var formElements = form.elements;
  
  for (var i = 0; i < formElements.length; i++) {
    var input = formElements[i];
    var name = input.name;
    
    // Skip buttons and non-field elements
    if (!name || input.type === 'submit' || input.type === 'button') continue;
    
    var errorId = errorPrefix + name.charAt(0).toUpperCase() + name.slice(1) + 'Error';
    var errorElement = document.getElementById(errorId);
    
    if (errorElement) {
      errorElement.textContent = '';
    }
    
    if (input.required && !input.value) {
      if (errorElement) {
        var labelText = name.charAt(0).toUpperCase() + name.slice(1).replace(/([A-Z])/g, ' $1');
        errorElement.textContent = labelText + ' is required';
      }
      isValid = false;
    } else if (name === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input.value)) {
      if (errorElement) {
        errorElement.textContent = 'Please enter a valid email address';
      }
      isValid = false;
    } else if (name === 'phone' && !/^[+\d() -]{7,20}$/.test(input.value)) {
      if (errorElement) {
        errorElement.textContent = 'Please enter a valid phone number';
      }
      isValid = false;
    }
  }
  
  if (form.id === 'bookingForm') {
    var pickupDate = new Date(form.elements['pickupDate'].value);
    var returnDate = new Date(form.elements['returnDate'].value);
    var today = new Date();
    today.setHours(0, 0, 0, 0);
    
    if (pickupDate < today) {
      document.getElementById('pickupDateError').textContent = 'Pickup date cannot be in the past';
      isValid = false;
    }
    
    if (returnDate <= pickupDate) {
      document.getElementById('returnDateError').textContent = 'Return date must be after pickup date';
      isValid = false;
    }
  }
  
  return isValid;
}

function showToast(message, type) {
  type = type || 'success';
  
  // Create toast element
  var toast = document.createElement('div');
  toast.className = 'toast ' + type;
  toast.textContent = message;
  
  // Add to document
  document.body.appendChild(toast);
  
  // Show toast
  setTimeout(function() {
    toast.classList.add('show');
  }, 10);
  
  // Hide and remove toast after 3 seconds
  setTimeout(function() {
    toast.classList.remove('show');
    setTimeout(function() {
      document.body.removeChild(toast);
    }, 300);
  }, 3000);
}

function handleBookingSubmit(e) {
  e.preventDefault();
  
  var submitBtn = document.getElementById('bookingSubmitBtn');
  submitBtn.disabled = true;
  submitBtn.textContent = 'PROCESSING...';
  
  if (validateForm(bookingForm, 'booking')) {
    // Simulate successful submission
    setTimeout(function() {
      showToast('Booking submitted successfully! We will contact you shortly to confirm your reservation.');
      bookingForm.reset();
      submitBtn.disabled = false;
      submitBtn.textContent = 'BOOK NOW';
    }, 1500);
  } else {
    submitBtn.disabled = false;
    submitBtn.textContent = 'BOOK NOW';
  }
}

function handleContactSubmit(e) {
  e.preventDefault();
  
  var submitBtn = document.getElementById('contactSubmitBtn');
  submitBtn.disabled = true;
  submitBtn.textContent = 'SENDING...';
  
  if (validateForm(contactForm, 'contact')) {
    // Simulate successful submission
    setTimeout(function() {
      showToast('Message sent successfully! We will get back to you as soon as possible.');
      contactForm.reset();
      submitBtn.disabled = false;
      submitBtn.textContent = 'SEND MESSAGE';
    }, 1500);
  } else {
    submitBtn.disabled = false;
    submitBtn.textContent = 'SEND MESSAGE';
  }
}

function handleNewsletterSubmit(e) {
  e.preventDefault();
  
  var emailInput = document.getElementById('newsletterEmail');
  var submitBtn = document.getElementById('newsletterSubmitBtn');
  submitBtn.disabled = true;
  submitBtn.textContent = 'SUBSCRIBING...';
  
  if (!emailInput.value || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailInput.value)) {
    showToast('Please enter a valid email address', 'error');
    submitBtn.disabled = false;
    submitBtn.textContent = 'SUBSCRIBE';
    return;
  }
  
  // Simulate successful submission
  setTimeout(function() {
    showToast('Thank you for subscribing to our newsletter!');
    emailInput.value = '';
    submitBtn.disabled = false;
    submitBtn.textContent = 'SUBSCRIBE';
  }, 1500);
}

function handleScroll() {
  // Header background
  if (window.scrollY > 10) {
    header.classList.add('scrolled');
  } else {
    header.classList.remove('scrolled');
  }
  
  // Back to top button
  if (window.scrollY > 300) {
    backToTop.classList.add('visible');
  } else {
    backToTop.classList.remove('visible');
  }
}

// Add CSS for toast notifications
var toastStyle = document.createElement('style');
toastStyle.textContent = '\
  .toast {\
    position: fixed;\
    bottom: 20px;\
    right: 20px;\
    padding: 15px 20px;\
    background-color: #4CAF50;\
    color: white;\
    border-radius: 4px;\
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);\
    z-index: 1000;\
    opacity: 0;\
    transform: translateY(20px);\
    transition: opacity 0.3s ease, transform 0.3s ease;\
    max-width: 350px;\
  }\
  \
  .toast.error {\
    background-color: #d41212;\
  }\
  \
  .toast.show {\
    opacity: 1;\
    transform: translateY(0);\
  }\
  \
  .header.scrolled {\
    background-color: rgba(255, 255, 255, 0.98);\
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);\
  }\
  \
  .menu-icon.active {\
    background-color: transparent;\
  }\
  \
  .menu-icon.active::before {\
    transform: rotate(45deg);\
    top: 0;\
  }\
  \
  .menu-icon.active::after {\
    transform: rotate(-45deg);\
    bottom: 0;\
  }\
';
document.head.appendChild(toastStyle);