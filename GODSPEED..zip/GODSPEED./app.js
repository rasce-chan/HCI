// DOM Elements
const header = document.getElementById('header');
const menuToggle = document.getElementById('menuToggle');
const mobileMenu = document.getElementById('mobileMenu');
const carGrid = document.getElementById('carGrid');
const categoryButtons = document.querySelectorAll('.category-btn');
const bookingForm = document.getElementById('bookingForm');
const carSelect = document.getElementById('carSelect');
const contactForm = document.getElementById('contactForm');
const newsletterForm = document.getElementById('newsletterForm');
const faqItems = document.querySelectorAll('.faq-item');
const backToTop = document.getElementById('backToTop');
const currentYearEl = document.getElementById('currentYear');

// Cars Data
const cars = [
  {
    id: 1,
    name: "Lamborghini Aventador",
    description: "The iconic V12 flagship Lamborghini with scissor doors and breathtaking performance.",
    image: "https://images.unsplash.com/photo-1544636331-e26879cd4d9b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=450",
    categoryId: 1,
    categoryName: "SUPERCAR",
    categorySlug: "supercars",
    horsepower: 730,
    acceleration: "2.8s 0-60",
    topSpeed: "217 mph",
    pricePerDay: 1500,
    isAvailable: true
  },
  {
    id: 2,
    name: "Lamborghini Huracan",
    description: "A V10-powered Italian exotic supercar with incredible performance and unmistakable styling.",
    image: "https://images.unsplash.com/photo-1580414057403-c5f451f30e1c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=450",
    categoryId: 1,
    categoryName: "SUPERCAR",
    categorySlug: "supercars",
    horsepower: 640,
    acceleration: "2.9s 0-60",
    topSpeed: "201 mph",
    pricePerDay: 1100,
    isAvailable: true
  },
  {
    id: 3,
    name: "McLaren 720S",
    description: "British engineering meets supercar performance with distinctive styling and cutting-edge technology.",
    image: "https://images.unsplash.com/photo-1617814065893-00757125efab?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=450",
    categoryId: 3,
    categoryName: "EXOTIC",
    categorySlug: "exotic",
    horsepower: 710,
    acceleration: "2.8s 0-60",
    topSpeed: "212 mph",
    pricePerDay: 1300,
    isAvailable: true
  },
  {
    id: 4,
    name: "McLaren Artura",
    description: "McLaren's latest hybrid supercar with plug-in technology and lightweight carbon fiber construction.",
    image: "https://images.unsplash.com/photo-1662555320015-158e64fbf337?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=450",
    categoryId: 3,
    categoryName: "EXOTIC",
    categorySlug: "exotic",
    horsepower: 671,
    acceleration: "3.0s 0-60",
    topSpeed: "205 mph",
    pricePerDay: 1250,
    isAvailable: true
  },
  {
    id: 5,
    name: "Audi R8 V10",
    description: "German precision engineering combines daily usability with supercar performance.",
    image: "https://images.unsplash.com/photo-1603584173870-7f23fdae1b7a?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=450",
    categoryId: 2,
    categoryName: "LUXURY",
    categorySlug: "luxury",
    horsepower: 562,
    acceleration: "3.4s 0-60",
    topSpeed: "201 mph",
    pricePerDay: 900,
    isAvailable: true
  },
  {
    id: 6,
    name: "Audi RS e-tron GT",
    description: "Audi's all-electric performance sedan with stunning design and instant acceleration.",
    image: "https://images.unsplash.com/photo-1606152421802-db97b9c7a11b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=450",
    categoryId: 2,
    categoryName: "LUXURY",
    categorySlug: "luxury",
    horsepower: 637,
    acceleration: "3.1s 0-60",
    topSpeed: "155 mph",
    pricePerDay: 850,
    isAvailable: true
  }
];

// Categories data
const categories = [
  {
    id: 1,
    name: "SUPERCAR",
    slug: "supercars"
  },
  {
    id: 2,
    name: "LUXURY",
    slug: "luxury"
  },
  {
    id: 3,
    name: "EXOTIC",
    slug: "exotic"
  }
];

// Initialize the site
document.addEventListener('DOMContentLoaded', function() {
  // Set current year in footer
  currentYearEl.textContent = new Date().getFullYear();
  
  // Animate hero section titles
  setTimeout(() => {
    document.querySelectorAll('.animated-title').forEach((title, index) => {
      setTimeout(() => {
        title.style.opacity = '1';
        title.style.transform = 'translateY(0)';
      }, 300 * index);
    });
  }, 500);
  
  // Initialize car grid
  renderCars('all');
  populateCarSelect();
  
  // Set min date for booking form
  const today = new Date().toISOString().split('T')[0];
  if (document.getElementById('pickupDate')) {
    document.getElementById('pickupDate').min = today;
  }
  if (document.getElementById('returnDate')) {
    document.getElementById('returnDate').min = today;
  }
  
  // Mobile menu toggle
  menuToggle.addEventListener('click', toggleMobileMenu);
  
  // Category filter
  categoryButtons.forEach(button => {
    button.addEventListener('click', function() {
      // Remove active class from all buttons
      categoryButtons.forEach(btn => btn.classList.remove('active'));
      
      // Add active class to clicked button
      this.classList.add('active');
      
      // Filter cars
      const category = this.getAttribute('data-category');
      renderCars(category);
    });
  });
  
  // FAQ toggles
  faqItems.forEach(item => {
    const question = item.querySelector('.faq-question');
    question.addEventListener('click', () => {
      item.classList.toggle('active');
    });
  });
  
  // Booking form submission
  if (bookingForm) {
    bookingForm.addEventListener('submit', handleBookingSubmit);
  }
  
  // Contact form submission
  if (contactForm) {
    contactForm.addEventListener('submit', handleContactSubmit);
  }
  
  // Newsletter form submission
  if (newsletterForm) {
    newsletterForm.addEventListener('submit', handleNewsletterSubmit);
  }
  
  // Back to top button
  window.addEventListener('scroll', handleScroll);
});

// Functions
function toggleMobileMenu() {
  mobileMenu.style.display = mobileMenu.style.display === 'block' ? 'none' : 'block';
  
  // Toggle menu icon
  const menuIcon = menuToggle.querySelector('.menu-icon');
  menuIcon.classList.toggle('active');
}

function renderCars(category) {
  // Filter cars by category
  const filteredCars = category === 'all' 
    ? cars 
    : cars.filter(car => car.categorySlug === category);
  
  // Clear car grid
  carGrid.innerHTML = '';
  
  // Render filtered cars
  filteredCars.forEach(car => {
    const carCard = document.createElement('div');
    carCard.className = 'car-card';
    carCard.innerHTML = `
      <div class="car-image">
        <img src="${car.image}" alt="${car.name}">
      </div>
      <div class="car-details">
        <div class="car-header">
          <h3 class="car-name">${car.name}</h3>
          <span class="car-category">${car.categoryName}</span>
        </div>
        <div class="car-specs">
          <span class="car-spec">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M12 2v5"/>
              <path d="m4.93 10.93 1.41 1.41"/>
              <path d="M2 18h20"/>
              <path d="M20 18a8 8 0 0 0-16 0"/>
            </svg>
            ${car.horsepower} HP
          </span>
          <span class="car-spec">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/>
            </svg>
            ${car.acceleration}
          </span>
          <span class="car-spec">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <circle cx="12" cy="12" r="10"/>
              <path d="M12 6v6l4 2"/>
            </svg>
            ${car.topSpeed}
          </span>
        </div>
        <div class="car-price">
          <span>
            <span class="price-amount">$${car.pricePerDay}</span>
            <span class="price-period">/day</span>
          </span>
          <a href="#booking" class="btn btn-secondary">BOOK NOW</a>
        </div>
      </div>
    `;
    carGrid.appendChild(carCard);
  });
}

function populateCarSelect() {
  if (!carSelect) return;
  
  cars.forEach(car => {
    const option = document.createElement('option');
    option.value = car.id;
    option.textContent = car.name;
    carSelect.appendChild(option);
  });
}

function validateForm(form, errorPrefix) {
  let isValid = true;
  const formData = new FormData(form);
  
  for (const [name, value] of formData.entries()) {
    const input = form.elements[name];
    const errorId = `${errorPrefix}${name.charAt(0).toUpperCase() + name.slice(1)}Error`;
    const errorElement = document.getElementById(errorId);
    
    if (errorElement) {
      errorElement.textContent = '';
    }
    
    if (input.required && !value) {
      if (errorElement) {
        errorElement.textContent = `${name.charAt(0).toUpperCase() + name.slice(1).replace(/([A-Z])/g, ' $1')} is required`;
      }
      isValid = false;
    } else if (name === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
      if (errorElement) {
        errorElement.textContent = 'Please enter a valid email address';
      }
      isValid = false;
    } else if (name === 'phone' && !/^[+\d() -]{7,20}$/.test(value)) {
      if (errorElement) {
        errorElement.textContent = 'Please enter a valid phone number';
      }
      isValid = false;
    } else if ((name === 'pickupDate' || name === 'returnDate') && !/^\d{4}-\d{2}-\d{2}$/.test(value)) {
      if (errorElement) {
        errorElement.textContent = 'Please select a valid date';
      }
      isValid = false;
    }
  }
  
  if (form.id === 'bookingForm') {
    const pickupDate = new Date(formData.get('pickupDate'));
    const returnDate = new Date(formData.get('returnDate'));
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    if (pickupDate < today) {
      document.getElementById('pickupDateError').textContent = 'Pickup date cannot be in the past';
      isValid = false;
    }
    
    if (returnDate <= pickupDate) {
      document.getElementById('returnDateError').textContent = 'Return date must be after pickup date';
      isValid = false;
    }
  }
  
  return isValid;
}

function showToast(message, type = 'success') {
  // Create toast element
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.textContent = message;
  
  // Add to document
  document.body.appendChild(toast);
  
  // Show toast
  setTimeout(() => {
    toast.classList.add('show');
  }, 10);
  
  // Hide and remove toast after 3 seconds
  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => {
      document.body.removeChild(toast);
    }, 300);
  }, 3000);
}

function handleBookingSubmit(e) {
  e.preventDefault();
  
  const submitBtn = document.getElementById('bookingSubmitBtn');
  submitBtn.disabled = true;
  submitBtn.textContent = 'PROCESSING...';
  
  if (validateForm(bookingForm, 'booking')) {
    // Simulate API request
    setTimeout(() => {
      showToast('Booking submitted successfully! We will contact you shortly to confirm your reservation.');
      bookingForm.reset();
      submitBtn.disabled = false;
      submitBtn.textContent = 'BOOK NOW';
    }, 1500);
  } else {
    submitBtn.disabled = false;
    submitBtn.textContent = 'BOOK NOW';
  }
}

function handleContactSubmit(e) {
  e.preventDefault();
  
  const submitBtn = document.getElementById('contactSubmitBtn');
  submitBtn.disabled = true;
  submitBtn.textContent = 'SENDING...';
  
  if (validateForm(contactForm, 'contact')) {
    // Simulate API request
    setTimeout(() => {
      showToast('Message sent successfully! We will get back to you as soon as possible.');
      contactForm.reset();
      submitBtn.disabled = false;
      submitBtn.textContent = 'SEND MESSAGE';
    }, 1500);
  } else {
    submitBtn.disabled = false;
    submitBtn.textContent = 'SEND MESSAGE';
  }
}

function handleNewsletterSubmit(e) {
  e.preventDefault();
  
  const emailInput = document.getElementById('newsletterEmail');
  const submitBtn = document.getElementById('newsletterSubmitBtn');
  submitBtn.disabled = true;
  submitBtn.textContent = 'SUBSCRIBING...';
  
  if (!emailInput.value || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailInput.value)) {
    showToast('Please enter a valid email address', 'error');
    submitBtn.disabled = false;
    submitBtn.textContent = 'SUBSCRIBE';
    return;
  }
  
  // Simulate API request
  setTimeout(() => {
    showToast('Thank you for subscribing to our newsletter!');
    emailInput.value = '';
    submitBtn.disabled = false;
    submitBtn.textContent = 'SUBSCRIBE';
  }, 1500);
}

function handleScroll() {
  // Header background
  if (window.scrollY > 10) {
    header.classList.add('scrolled');
  } else {
    header.classList.remove('scrolled');
  }
  
  // Back to top button
  if (window.scrollY > 300) {
    backToTop.classList.add('visible');
  } else {
    backToTop.classList.remove('visible');
  }
}

// Add CSS for toast notifications
const toastStyle = document.createElement('style');
toastStyle.textContent = `
  .toast {
    position: fixed;
    bottom: 20px;
    right: 20px;
    padding: 15px 20px;
    background-color: #4CAF50;
    color: white;
    border-radius: 4px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    z-index: 1000;
    opacity: 0;
    transform: translateY(20px);
    transition: opacity 0.3s ease, transform 0.3s ease;
    max-width: 350px;
  }
  
  .toast.error {
    background-color: #d41212;
  }
  
  .toast.show {
    opacity: 1;
    transform: translateY(0);
  }
  
  .header.scrolled {
    background-color: rgba(255, 255, 255, 0.98);
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
  }
  
  .menu-icon.active {
    background-color: transparent;
  }
  
  .menu-icon.active::before {
    transform: rotate(45deg);
    top: 0;
  }
  
  .menu-icon.active::after {
    transform: rotate(-45deg);
    bottom: 0;
  }
`;
document.head.appendChild(toastStyle);